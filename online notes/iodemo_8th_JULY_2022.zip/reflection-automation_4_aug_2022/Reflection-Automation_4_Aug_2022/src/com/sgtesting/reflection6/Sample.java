package com.sgtesting.reflection6;

public class Sample {
	
	public void showFN(String fname)
	{
		System.out.println("The First Name is "+fname);
	}
	
	public void displayDetails(String fname,String lname)
	{
		System.out.println(fname+" ------> "+lname);
	}
	
	public void showAge(int age)
	{
		System.out.println("Age is :"+age);
	}

}
