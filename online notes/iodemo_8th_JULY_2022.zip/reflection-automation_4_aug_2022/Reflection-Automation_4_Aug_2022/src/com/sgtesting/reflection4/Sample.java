package com.sgtesting.reflection4;

public class Sample {
	static
	{
		display1();
		display2();
		display3();
		display4();
		display5();
		display6();
		display7();
		display8();
		display9();
		display10();
	}
	public static void display1()
	{
		System.out.println("It is display1 method statement...");
	}
	public static void display2()
	{
		System.out.println("It is display2 method statement...");
	}
	
	public static void display3()
	{
		System.out.println("It is display3 method statement...");
	}
	
	public static void display4()
	{
		System.out.println("It is display4 method statement...");
	}
	
	public static void display5()
	{
		System.out.println("It is display5 method statement...");
	}
	
	public static void display6()
	{
		System.out.println("It is display6 method statement...");
	}
	
	public static void display7()
	{
		System.out.println("It is display7 method statement...");
	}
	
	public static void display8()
	{
		System.out.println("It is display8 method statement...");
	}
	
	public static void display9()
	{
		System.out.println("It is display9 method statement...");
	}
	
	public static void display10()
	{
		System.out.println("It is display10 method statement...");
	}

}
